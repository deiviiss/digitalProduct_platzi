// var a=1;
// var b=2;
// var nombre="Rulótico";
// var apellido="González";
//
// var nombreCompleto=nombre+" "+apellido;
//
// alert("Holi "+nombreCompleto);
